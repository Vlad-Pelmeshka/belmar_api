<nav class="uk-navbar-container" uk-navbar>
    <div class="uk-container">
        <ul class="uk-navbar-nav">
            <li class="uk-active"><a href="/">Form</a></li>
            <li><a href="/table">Table</a></li>
        </ul>
    </div>
</nav>